﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spaceships
{
    public class Rocinante:Spaceship, IIonDrive, IShip, IShoot
    {
        Random damage = new Random();
        Random multiplier = new Random();

        public int LightKeelMountedRailgun { get; set; }

        public int Szorzo { get; set; }

        public bool OnIon { get; set; }

        public Rocinante()
        {
        }

        public Rocinante(string name, Captain captain, int speed, int shield) : base(name, captain, speed, shield)
        {
            LightKeelMountedRailgun = damage.Next(10, 101);
            Szorzo = multiplier.Next(6, 10);
            OnIon = false;
        }

        public bool GetIonStatus()
        {
            return OnIon;
        }

        public int GetSzorzo()
        {
            return Szorzo;
        }

        public override int GetGun()
        {
            LightKeelMountedRailgun = damage.Next(10, 101);
            return LightKeelMountedRailgun;
        }    
        public int GetShipBoostedSpeed()
        {
            return Speed;
        }
        public int JumpToIonSpeed(int ionspeed)
        {          
            if (OnIon)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("You are already in IonSpeed!");
                Console.ResetColor();
                return Speed;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("Succesful speedup!");
                Console.ResetColor();
                OnIon = true;
                return Speed += (ionspeed * 5);
            }
        }
        public override void Accelration()
        {
            JumpToIonSpeed(Speed);
        }
        public override string SelfDestruct()
        {
            Status = false;
            return $"You have self destructed your spaceship ({Name})";
        }
    }
}
