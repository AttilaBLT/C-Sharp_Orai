﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spaceships
{
    public static class Actions
    {
        public static void MilleniumEnemyGenerate(Captain captain) 
        {
            MilleniumFalcon enemy1 = new MilleniumFalcon("MilleniumFalcon", captain, 20, 40);
        }
        public static string Attack(Spaceship attacker, Spaceship attacked)
        {
            if (attacked.GetStatus())
            {
                if (attacked.GetSpeed() <= attacker.GetSpeed())
                {
                    if (attacked.getShield() < attacker.GetGun())
                    {
                        attacked.Status = false;
                        return $"{attacker.getName()}'s attack successful against: {attacked.getName()}";
                    }
                    else
                    {
                        return $"The {attacked.getName()} spacehips's shield is too powerful.";
                    }
                }
                else
                {
                    return $"Your spaceship ({attacker.getName()}) is too slow to attack.";
                }
            }
            else
            {
                return $"This spaceship is already destroyed.";
            }
        }
    }
}
