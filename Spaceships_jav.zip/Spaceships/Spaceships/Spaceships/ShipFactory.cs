﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spaceships
{
    public static class ShipFactory
    {
        public static void SelectSpaceship()
        {
            string ship;
            Captain ati = new Captain("Attikka", Ranks.Captain);
            Captain andor = new Captain("Bandi", Ranks.Admiral);
            Captain peti = new Captain("Péterke", Ranks.Major);
            Console.WriteLine("Choose your spaceship! (Millenium Falcon | Enterprise | Rocinante)");
            ship = Console.ReadLine();
            Spaceship selectedShip = ShipFactory.GetShip(ship, ati, andor, peti);
            Spaceship enemy1 = ShipFactory.GetEnemy1(ship, ati, andor, peti);
            Spaceship enemy2 = ShipFactory.GetEnemy2(ship, ati, andor, peti);
            Program.ChooseAction(selectedShip, enemy1, enemy2);
        }
        public static Spaceship GetShip(string ship, Captain ati, Captain andor, Captain peti) 
        {
            if (ship.ToLower() == "millenium falcon")
            {               
                Console.WriteLine("You have choosen: Millenium Falcon");
                return new MilleniumFalcon("MilleniumFalcon", ati, 20, 40);
            }
            else if (ship.ToLower() == "enterprise")
            {
                Console.WriteLine("You have choosen: Enterprise");
                return new Enterprise("Enterprise", andor, 20, 40);

            }
            else if (ship.ToLower() == "rocinante")
            {
                            
                Console.WriteLine("You have choosen: Rocinante");
                return new Rocinante("Rocinante", peti, 20, 40);
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("There is no ship with that name!");
                Console.ResetColor();
                ShipFactory.SelectSpaceship();
                return null;
            }
        }
        public static Spaceship GetEnemy1(string ship, Captain ati, Captain andor, Captain peti)
        {
            string[] ships = {"milleniumfalcon" , "enterprise" , "rocinante"};
            var shipslist = ships.ToList();
            shipslist.Remove(ship);
            if (shipslist[0].ToLower() == "milleniumfalcon")
            {              
                return new MilleniumFalcon("MilleniumFalcon", ati, 20, 40);
            }
            else if (shipslist[0].ToLower() == "enterprise")
            {
                return new Enterprise("Enterprise", andor, 20, 40);

            }
            else if (shipslist[0].ToLower() == "rocinante")
            {
                return new Rocinante("Rocinante", peti, 20, 40);
            }
            else
            {
                throw new Exception("This ship does not exists.");
            }
        }
        public static Spaceship GetEnemy2(string ship, Captain ati, Captain andor, Captain peti)
        {
            string[] ships = { "milleniumfalcon", "enterprise", "rocinante" };
            var shipslist = ships.ToList();
            shipslist.Remove(ship);
            if (shipslist[1].ToLower() == "milleniumfalcon")
            {
                return new MilleniumFalcon("MilleniumFalcon", ati, 20, 40);
            }
            else if (shipslist[1].ToLower() == "enterprise")
            {
                return new Enterprise("Enterprise", andor, 20, 40);

            }
            else if (shipslist[1].ToLower() == "rocinante")
            {
                return new Rocinante("Rocinante", peti, 20, 40);
            }
            else
            {
                throw new Exception("This ship does not exists.");
            }
        }
    }
}
