﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spaceships
{
    public abstract class Spaceship:IShip
    {
        public string Name { get; set; }

        public Captain Captain { get; set; }

        public int Speed { get; set; }

        public int Shield { get; set; }

        public bool Status { get; set; }

        public Spaceship()
        {
        }

        public Spaceship(string name, Captain captain, int speed, int shield)
        {
            Name = name;
            Captain = captain;
            Speed = speed;
            Shield = shield;
            Status = true;
        }
        public string getName()
        {
            return Name;
        }
        public bool GetStatus()
        {
            return Status;
        }
        public int GetSpeed()
        {
            return Speed;
        }
        public int getShield()
        {
            return Shield;
        }
        public abstract int GetGun();
        //public abstract string Attack(string attacked, int enemyspeed, int enemyshield, bool enemystatus);
        public Spaceship GetShip() 
        {
            return null;
        }
        public abstract void Accelration();
        public abstract string SelfDestruct();
    }
}
