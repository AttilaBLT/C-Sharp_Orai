﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spaceships
{
    public class Captain
    {
        public string Name { get; set; }

        public Ranks Rank { get; set; }

        public Captain()
        {
        }
        public Captain(string name, Ranks rank)
        {
            Name = name;
            Rank = rank;
        }
    }
}
