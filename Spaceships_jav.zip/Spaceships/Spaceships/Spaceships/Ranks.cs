﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spaceships
{
    public enum Ranks
    {
        Captain = 1,
        Major = 2,
        Admiral = 3
    }
}
