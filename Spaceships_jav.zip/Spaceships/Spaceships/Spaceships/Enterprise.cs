﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spaceships
{
    public class Enterprise : Spaceship, IHyperDrive, IShip, IShoot
    {
        Random damage = new Random();
        Random multiplier = new Random();

        public int FotonTorpedo { get; set; }

        public int Szorzo { get; set; }

        public bool OnHyper { get; set; }

        public Enterprise()
        {
        }
        public Enterprise(string name, Captain captain, int speed, int shield) : base(name, captain, speed, shield)
        {
            FotonTorpedo = damage.Next(10, 101);
            Szorzo = multiplier.Next(5, 11);
            OnHyper = false;
        }
     
        public bool GetHyperStatus()
        {
            return OnHyper;
        }

        public int GetSzorzo()
        {
            return Szorzo;
        }
        public override int GetGun()
        {
            FotonTorpedo = damage.Next(10, 101);
            return FotonTorpedo;
        }
        public override string SelfDestruct()
        {
            Status = false;
            return $"You have self destructed your spaceship ({Name})";
        }
        public int GetShipBoostedSpeed()
        {
            return Speed;
        }
        public int JumpToHyperSpeed(int hyperspeed)
        {
            if (OnHyper)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("You are already in HyperSpeed!");
                Console.ResetColor();
                return Speed;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("Succesful speedup!");
                Console.ResetColor();
                OnHyper = true;
                return Speed += (hyperspeed * 10);
            }
        }
        public override void Accelration()
        {
            JumpToHyperSpeed(Speed);
        }

    }
}
