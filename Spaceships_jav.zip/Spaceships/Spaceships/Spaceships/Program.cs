﻿using System;

namespace Spaceships
{
    class Program
    {
        static void Main(string[] args)
        {

            ShipFactory.SelectSpaceship();
            

            
            //Console.WriteLine(selectedShip.GetGun());
            
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Game over!");
            Console.ResetColor();
            Console.ReadKey();
        }
        public static void ChooseAction(Spaceship selectedShip, Spaceship enemy1, Spaceship enemy2)
        {
            string action;
            string target;
            while (selectedShip.GetStatus() && (enemy1.GetStatus() || enemy2.GetStatus()))
            {
                Console.WriteLine("What would you like to do? (Attack (A) | Speedup (S) | Selfdistruction (D))");
                action = Console.ReadLine();
                while (action.ToLower() == "a" || action.ToLower() == "s" || action.ToLower() == "d")
                {
                    Console.Clear();
                    switch (action.ToLower())
                    {
                        case "a":
                            Console.Clear();
                            Console.WriteLine($"Who would you like to attack. Enemies: 1.{enemy1.getName()} or 2.{enemy2.getName()} (1 or 2 or cancel)");
                            target = Console.ReadLine();
                            if (target == "1")
                            {
                                Console.WriteLine(Actions.Attack(selectedShip, enemy1));
                            }
                            else if (target == "2")
                            {
                                Console.WriteLine(Actions.Attack(selectedShip, enemy2));
                            }
                            break;
                        case "s":
                            Console.Clear();
                            selectedShip.Accelration();
                            break;
                        case "d":
                            Console.Clear();
                            Console.WriteLine(selectedShip.SelfDestruct());
                            break;
                        default:
                            break;
                    }
                    break;
                }

            }
        }
    }
}