﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spaceships
{
    public class MilleniumFalcon:Spaceship, IHyperDrive, IShip, IShoot
    {
        Random damage = new Random();
        Random multiplier = new Random();

        public int MilleniumGun { get; set; }

        public int Szorzo { get; set; }

        public bool OnHyper { get; set; }

        public MilleniumFalcon()
        {
        }
        public MilleniumFalcon(string name, Captain captain, int speed, int shield):base(name, captain, speed, shield)
        {
            MilleniumGun = damage.Next(10, 101);
            Szorzo = multiplier.Next(5, 11);
            OnHyper = false;
        }

        public bool GetHyperStatus()
        {
            return OnHyper;
        }
        public int GetSzorzo()
        {
            return Szorzo;
        }
        public override int GetGun()
        {
            MilleniumGun = damage.Next(10, 101);
            return MilleniumGun;
        }
        public override string SelfDestruct()
        {
            Status = false;
            return $"You have self destructed your spaceship ({Name})";
        }
        public int JumpToHyperSpeed( int hyperspeed)
        {
            if (OnHyper)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("You are already in HyperSpeed!");
                Console.ResetColor();
                return Speed;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("Succesful speedup!");
                Console.ResetColor();
                OnHyper = true;
                return Speed += (hyperspeed * 10);
            }
        }
        public override void Accelration()
        {
            JumpToHyperSpeed(Speed);
        }
    }
}
