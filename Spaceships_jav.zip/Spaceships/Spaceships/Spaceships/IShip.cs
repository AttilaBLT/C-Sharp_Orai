﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spaceships
{
    public interface IShip
    {
        public Spaceship GetShip();
        public int GetGun();
    }
}
